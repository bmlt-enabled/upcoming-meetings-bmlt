<?php
// Silence, she blinded me with silence.